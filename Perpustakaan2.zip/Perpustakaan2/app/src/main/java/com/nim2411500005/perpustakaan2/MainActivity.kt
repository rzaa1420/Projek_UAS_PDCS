package com.nim2411500005.perpustakaan2

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

data class ListItem(val id_buku: Int, val judul: String, val author: String, val cover: String)
class MainActivity : AppCompatActivity() {
    private lateinit var listView: ListView
    private lateinit var listAdapter: ListAdapter
    private lateinit var searchEditText: EditText
    private lateinit var logoutButton: Button
    private lateinit var welcomeTextView: TextView
    private lateinit var sharedPreferences: SharedPreferences

    private val allItems = ArrayList<ListItem>()

    private var filteredItems = ArrayList(allItems)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        sharedPreferences = getSharedPreferences("UserPrefs", Context.MODE_PRIVATE)

        listView = findViewById(R.id.listView)
        searchEditText = findViewById(R.id.searchEditText)
        logoutButton = findViewById(R.id.logoutButton)
        welcomeTextView = findViewById(R.id.welcomeTextView)
        listAdapter = ListAdapter(this, filteredItems)
        listView.adapter = listAdapter

        // Menampilkan welcome message dengan username
        val username = sharedPreferences.getString("username", "")
        if (!username.isNullOrEmpty()) {
            welcomeTextView.text = "Welcome $username.."
        }

        fetchBooksFromAPI()

        searchEditText.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                filterList(s.toString())
            }

            override fun afterTextChanged(p0: Editable?) {}
        })

        logoutButton.setOnClickListener {
            logout()
        }

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }


    private fun fetchBooksFromAPI() {
        Thread {
            try {
                val url = URL("http://192.168.43.148/perpustakaan-uts/api/film.php")
                val conn = url.openConnection() as HttpURLConnection
                conn.requestMethod = "GET"
                conn.connect()

                val responseBody = conn.inputStream.bufferedReader().use {it.readText()}
                println("RESPONSE API = $responseBody")

                val json = JSONObject(responseBody)
                val dataArray = json.getJSONArray("data")

                val tempList = ArrayList<ListItem>()

                for (i in 0 until dataArray.length()) {
                    val o = dataArray.getJSONObject(i)
                    tempList.add(
                        ListItem(
                            id_buku = o.getString("id_film").toInt(),
                            judul = o.getString("judul"),
                            author = o.getString("sutradara"),
                            cover = o.getString("cover")

                        )
                    )
                }

                println("Jumlah DATA = ${tempList.size}")

                runOnUiThread {
                    allItems.clear()
                    allItems.addAll(tempList)

                    filteredItems.clear()
                    filteredItems.addAll(tempList)
                    listAdapter.updateList(filteredItems)
                }

            } catch (e: Exception) {
                e.printStackTrace()
            }
        }.start()
    }

    private fun filterList(query: String) {
        val filteredList = if (query.isEmpty()) {
            allItems
        } else {
            allItems.filter { item ->
                item.judul.contains(query, ignoreCase = true) ||
                        item.author.contains(query, ignoreCase = true)
            }
        }
         listAdapter.updateList(ArrayList(filteredList))
    }

    private fun logout() {
        // Clear status login
        val editor = sharedPreferences.edit()
        editor.putBoolean("isLoggedIn", false)
        editor.apply()

        // Redirect ke LoginActivity
        val intent = Intent(this, LoginActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)
        finish()
    }
}