package com.nim2411500005.perpustakaan2

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity

class LoginActivity : AppCompatActivity() {
    private lateinit var emailEditText: EditText
    private lateinit var passwordEditText: EditText
    private lateinit var loginButton: Button
    private lateinit var errorTextView: TextView
    private lateinit var sharedPreferences: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_login)

        sharedPreferences = getSharedPreferences("UserPrefs", Context.MODE_PRIVATE)

        emailEditText = findViewById(R.id.emailEditText)
        passwordEditText = findViewById(R.id.passwordEditText)
        loginButton = findViewById(R.id.loginButton)
        errorTextView = findViewById(R.id.errorTextView)

        // Auto-fill email dari Intent (dari RegisterActivity) atau dari SharedPreferences
        val emailFromIntent = intent.getStringExtra("email")
        val savedEmail = sharedPreferences.getString("email", "")
        
        when {
            !emailFromIntent.isNullOrEmpty() -> {
                emailEditText.setText(emailFromIntent)
            }
            !savedEmail.isNullOrEmpty() -> {
                emailEditText.setText(savedEmail)
            }
        }

        loginButton.setOnClickListener {
            loginUser()
        }
    }

    private fun loginUser() {
        val email = emailEditText.text.toString().trim()
        val password = passwordEditText.text.toString()
        val savedEmail = sharedPreferences.getString("email", "")
        val savedPassword = sharedPreferences.getString("password", "")

        // Validasi
        if (email.isEmpty()) {
            showError("Email tidak boleh kosong")
            return
        }

        if (password.isEmpty()) {
            showError("Password tidak boleh kosong")
            return
        }

        // Verifikasi email dan password
        if (email == savedEmail && password == savedPassword) {
            // Simpan status login
            val editor = sharedPreferences.edit()
            editor.putBoolean("isLoggedIn", true)
            editor.apply()

            // Pindah ke MainActivity
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
            finish()
        } else {
            showError("Email atau password salah")
        }
    }

    private fun showError(message: String) {
        errorTextView.text = message
        errorTextView.visibility = TextView.VISIBLE
    }
}