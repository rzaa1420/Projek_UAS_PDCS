package com.nim2411500005.perpustakaan2

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity

class RegisterActivity : AppCompatActivity() {
    private lateinit var usernameEditText: EditText
    private lateinit var emailEditText: EditText
    private lateinit var passwordEditText: EditText
    private lateinit var confirmPasswordEditText: EditText
    private lateinit var registerButton: Button
    private lateinit var errorTextView: TextView
    private lateinit var sharedPreferences: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_register)

        sharedPreferences = getSharedPreferences("UserPrefs", Context.MODE_PRIVATE)

        usernameEditText = findViewById(R.id.usernameEditText)
        emailEditText = findViewById(R.id.emailEditText)
        passwordEditText = findViewById(R.id.passwordEditText)
        confirmPasswordEditText = findViewById(R.id.confirmPasswordEditText)
        registerButton = findViewById(R.id.registerButton)
        errorTextView = findViewById(R.id.errorTextView)

        registerButton.setOnClickListener {
            registerUser()
        }
    }

    private fun registerUser() {
        val username = usernameEditText.text.toString().trim()
        val email = emailEditText.text.toString().trim()
        val password = passwordEditText.text.toString()
        val confirmPassword = confirmPasswordEditText.text.toString()

        // Validasi
        if (username.isEmpty()) {
            showError("Username tidak boleh kosong")
            return
        }

        if (email.isEmpty()) {
            showError("Email tidak boleh kosong")
            return
        }

        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            showError("Format email tidak valid")
            return
        }

        if (password.isEmpty()) {
            showError("Password tidak boleh kosong")
            return
        }

        if (password.length < 6) {
            showError("Password minimal 6 karakter")
            return
        }

        if (password != confirmPassword) {
            showError("Password dan Confirm Password tidak sama")
            return
        }

        // Simpan data ke SharedPreferences
        val editor = sharedPreferences.edit()
        editor.putString("username", username)
        editor.putString("email", email)
        editor.putString("password", password)
        editor.putBoolean("isRegistered", true)
        editor.apply()

        // Pindah ke LoginActivity dengan membawa email
        val intent = Intent(this, LoginActivity::class.java)
        intent.putExtra("email", email)
        startActivity(intent)
        finish()
    }

    private fun showError(message: String) {
        errorTextView.text = message
        errorTextView.visibility = TextView.VISIBLE
    }
}